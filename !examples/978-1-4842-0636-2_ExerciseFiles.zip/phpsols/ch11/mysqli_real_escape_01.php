<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>MySQLi: Insert String</title>
</head>

<body>
<form method="get" action="">
    <input type="search" name="search" id="search">
    <input type="submit" name="go" id="go" value="Search">
</form>
<p>Number of results for <b></b>: </p>
<table>
    <tr>
        <th>image_id</th>
        <th>filename</th>
        <th>caption</th>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
    </tr>
</table>
</body>
</html>