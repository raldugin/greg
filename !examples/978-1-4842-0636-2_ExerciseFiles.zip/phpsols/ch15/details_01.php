<!DOCTYPE HTML>
<html>
<head>
    <meta  charset="utf-8">
    <title>Japan Journey</title>
    <link href="styles/journey.css" rel="stylesheet" type="text/css">
</head>

<body>
<header>
    <h1>Japan Journey </h1>
</header>
<div id="wrapper">
    <?php require './includes/menu.php'; ?>
    <main>
        <h2>Article Title Goes Here</h2>
        <p>Saturday, October 2nd, 2014</p>
        <figure>
            <img src="images/basin.jpg" alt="">
        </figure>
        <p>Article contents go here.</p>
        <p><a href="blog.php">Back to the blog </a></p>
    </main>
    <?php include './includes/footer.php'; ?>
</div>
</body>
</html>
