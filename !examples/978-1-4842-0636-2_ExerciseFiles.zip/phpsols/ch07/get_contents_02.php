<!DOCTYPE HTML>
<html>
<head>
<meta  charset="utf-8">
<title>Read File in a Single Operation</title>
</head>

<body>
<?php nl2br(readfile('C:/private/sonnet.txt')); ?>
</body>
</html>