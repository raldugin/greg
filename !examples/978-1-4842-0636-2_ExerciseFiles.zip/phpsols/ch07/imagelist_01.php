<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Automatically Generated Image Menu</title>
</head>

<body>
<form method="post" action="">
    <select name="pix" id="pix">
        <option value="">Select an image</option>
    </select>
</form>
</body>
</html>