<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Download Images</title>
</head>

<body>
    <p><a href="download.php?file=maiko.jpg">Download image 1</a></p>
    <p><a href="download.php?file=basin.jpg">Download image 2</a></p>
</body>
</html>