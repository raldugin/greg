<!DOCTYPE HTML>
<html>
<head>
<meta  charset="utf-8">
<title>Read File in a Single Operation</title>
</head>

<body>
<?php echo nl2br(file_get_contents('C:/private/sonnet.txt')); ?>
</body>
</html>