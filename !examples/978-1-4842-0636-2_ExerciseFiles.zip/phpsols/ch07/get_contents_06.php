<!DOCTYPE HTML>
<html>
<head>
<meta  charset="utf-8">
<title>Directly Accessing Array Element</title>
</head>

<body>
<?php echo file('C:/private/sonnet.txt')[10]; ?>
</body>
</html>