<!DOCTYPE HTML>
<html>
<head>
    <meta  charset="utf-8">
    <title>Using scandir() to Inspect the Contents of a Folder</title>
</head>

<body>
<pre>
<?php print_r(scandir('../images')); ?>
</pre>
</body>
</html>