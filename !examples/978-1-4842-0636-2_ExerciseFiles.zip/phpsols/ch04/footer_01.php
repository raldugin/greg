<footer>
    <p>&copy; 2006&ndash;2014 David Powers</p>
</footer>
 