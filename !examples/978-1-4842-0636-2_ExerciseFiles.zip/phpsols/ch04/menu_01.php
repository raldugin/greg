<ul id="nav">
    <li><a href="index.php" id="here">Home</a></li>
    <li><a href="blog.php">Blog</a></li>
    <li><a href="gallery.php">Gallery</a></li>
    <li><a href="contact.php">Contact</a></li>
</ul>
