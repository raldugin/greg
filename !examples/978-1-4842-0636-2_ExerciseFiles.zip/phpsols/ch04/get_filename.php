<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>$_SERVER['SCRIPT_FILENAME']</title>
</head>

<body>
<p><strong>$_SERVER['SCRIPT_FILENAME']:</strong> <?php echo $_SERVER['SCRIPT_FILENAME']; ?></p>
<p><strong>basename($_SERVER['SCRIPT_FILENAME']):</strong> <?php echo basename($_SERVER['SCRIPT_FILENAME']); ?></p>
</body>
</html>
