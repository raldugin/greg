<?php
require_once '../includes/session_timeout_db.php';
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Secret page</title>
</head>

<body>
<h1>Restricted area</h1>
<p><a href="menu_db.php">Back to restricted menu</a> </p>
<?php include '../includes/logout_db.php'; ?>
</body>
</html>
