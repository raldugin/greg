<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Session test</title>
</head>

<body>
<form method="post" action="session_02.php">
    <p>
        <label for="name">Name:</label>
        <input type="text" name="name" id="name">
    </p>
    <p>
        <input type="submit" name="Submit" value="Submit">
    </p>
</form>
</body>
</html>
