<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Multiple form 1</title>
</head>

<body>
<form method="post" action="">
    <p>
        <label for="first_name">First name:</label>
        <input type="text" name="first_name" id="first_name" required>
    </p>
    <p>
        <label for="family_name">Family name:</label>
        <input type="text" name="family_name" id="family_name">
    </p>
    <p>
        <input type="submit" name="next" value="Next &gt;">
    </p>
</form>
</body>
</html>
