<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Multiple form 4</title>
</head>

<body>
<p>The details submitted were as follows: </p>
<ul>
</ul>
</body>
</html>
