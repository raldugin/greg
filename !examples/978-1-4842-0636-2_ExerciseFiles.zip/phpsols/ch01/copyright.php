<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Copyright</title>
<style type="text/css">
body {
	background-color:#fff;
	color:#000;
	font-family:"Lucida Sans Unicode", "Lucida Grande", sans-serif;
}
</style>
</head>

<body>
<p>&copy; <?php echo date('Y'); ?> PHP Solutions</p>
</body>
</html>