<!DOCTYPE HTML>
<html>
<head>
<meta  charset="utf-8">
<title>Inspecting an array with print_r()</title>
</head>

<body>
<?php
$book = ['title'     => 'PHP Solutions: Dynamic Web Design Made Easy, Third Edition',
         'author'    => 'David Powers',
         'publisher' => 'Apress',
         'ISBN'      => '978-1-4842-0636-2'
];
print_r($book);
?>
</body>
</html>
