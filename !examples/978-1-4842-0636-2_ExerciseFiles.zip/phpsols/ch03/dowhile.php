<!DOCTYPE HTML>
<html>
<head>
<meta  charset="utf-8">
<title>Do... while loop</title>
</head>

<body>
<?php
$i = 1000;
do {
    echo "$i<br>";
    $i++; // increase counter by 1
} while ($i <= 100);
?>
</body>
</html>
