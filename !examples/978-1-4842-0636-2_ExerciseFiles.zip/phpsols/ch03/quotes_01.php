<!DOCTYPE HTML>
<html>
<head>
<meta  charset="utf-8">
<title>Enclosing Variables in Single Quotes</title>
</head>

<body>
<?php
$name = 'Dolly';
// Single quotes: $name is treated as literal text
echo 'Hello, $name';
?>
</body>
</html>