<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Automatic data type conversion</title>
</head>

<body>
<?php
$fruit = '2 apples';
$veg = ' and 2 carrots';
echo $fruit + $veg;
?>
</body>
</html>
