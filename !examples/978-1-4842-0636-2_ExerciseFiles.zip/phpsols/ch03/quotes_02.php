<!DOCTYPE HTML>
<html>
<head>
<meta  charset="utf-8">
<title>Enclosing Variables in Double Quotes</title>
</head>

<body>
<?php
$name = 'Dolly';
// Double quotes: $name is processed
echo "Hello, $name";
?>
</body>
</html>