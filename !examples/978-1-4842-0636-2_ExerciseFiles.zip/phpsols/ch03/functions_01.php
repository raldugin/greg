<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Simple function with no arguments</title>
</head>

<body>
<?php
function sayHi() {
    echo 'Hi!';
}
sayHi();
?>
</body>
</html>
