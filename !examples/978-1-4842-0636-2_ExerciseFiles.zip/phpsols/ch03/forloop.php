<!DOCTYPE HTML>
<html>
<head>
<meta  charset="utf-8">
<title>For loop</title>
</head>

<body>
<?php
for ($i = 1; $i <= 100; $i++) {
    echo "$i<br>";
}
?>
</body>
</html>
