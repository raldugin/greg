<!DOCTYPE HTML>
<html>
<head>
<meta  charset="utf-8">
<title>While loop</title>
</head>

<body>
<?php
$i = 1; // set counter
while ($i <= 100) {
    echo "$i<br>";
    $i++; // increase counter by 1
}
?>
</body>
</html>
